package com.example.imagesearchapp.ui.detail

import androidx.fragment.app.Fragment
import com.example.imagesearchapp.R

class DetailsFragment:Fragment(R.layout.fragment_details) {


}